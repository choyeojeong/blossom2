-- 중3 단어대전: Supabase SQL Editor에서 한 번만 전체 실행하세요.
create extension if not exists pgcrypto;

create table if not exists public.word_battle_settings (
  id integer primary key default 1 check (id = 1),
  event_title text not null default '중3 단어대전',
  event_subtitle text not null default '단어를 쌓고, 팀의 기록을 높여라!',
  event_body text not null default '2026. 9. 14. ~ 10. 31.',
  rules_title text not null default '중3 단어대전 규칙',
  rules_body text not null default '단어시험에 통과한 범위의 단어만 인정됩니다.',
  intro_bg text not null default '#173f8a',
  rules_bg text not null default '#0f6b5d',
  accent_color text not null default '#ffd34e',
  slide_seconds integer not null default 8 check (slide_seconds between 3 and 60),
  start_date date not null default '2026-09-14',
  end_date date not null default '2026-10-31',
  updated_at timestamptz not null default now()
);

create table if not exists public.word_battle_teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  color text not null default '#3478f6',
  sort_order integer not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (sort_order)
);

create table if not exists public.word_battle_members (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.word_battle_teams(id) on delete cascade,
  student_id uuid references public.students(id) on delete set null,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists word_battle_members_student_unique
  on public.word_battle_members(student_id) where student_id is not null;

create table if not exists public.word_battle_entries (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.word_battle_members(id) on delete cascade,
  entry_date date not null,
  word_count integer not null default 0 check (word_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(member_id, entry_date)
);

insert into public.word_battle_settings
  (id, event_title, event_subtitle, event_body, rules_title, rules_body, intro_bg, rules_bg, accent_color, slide_seconds, start_date, end_date)
values
  (1, '중3 단어대전', '단어를 쌓고, 팀의 기록을 높여라!', E'2026. 9. 14. ~ 10. 31.\n매일의 통과가 우리 팀의 점수가 됩니다.', '중3 단어대전 규칙', E'1. 단어시험에 통과한 범위의 단어만 인정됩니다.\n2. 학생별 통과 단어 수를 매일 누적합니다.\n3. 대전 종료일까지 가장 많은 단어를 쌓은 팀이 우승합니다.\n4. 정직하게, 끝까지, 함께 도전합니다!', '#173f8a', '#0f6b5d', '#ffd34e', 8, '2026-09-14', '2026-10-31')
on conflict (id) do nothing;

insert into public.word_battle_teams (name, color, sort_order)
select seed.name, seed.color, seed.sort_order
from (values ('블루팀','#3478f6',1),('레드팀','#f05454',2),('그린팀','#23a36d',3),('옐로팀','#f2b632',4)) as seed(name,color,sort_order)
where not exists (select 1 from public.word_battle_teams);

alter table public.word_battle_settings enable row level security;
alter table public.word_battle_teams enable row level security;
alter table public.word_battle_members enable row level security;
alter table public.word_battle_entries enable row level security;

drop policy if exists "word battle settings all" on public.word_battle_settings;
drop policy if exists "word battle teams all" on public.word_battle_teams;
drop policy if exists "word battle members all" on public.word_battle_members;
drop policy if exists "word battle entries all" on public.word_battle_entries;
create policy "word battle settings all" on public.word_battle_settings for all to anon, authenticated using (true) with check (true);
create policy "word battle teams all" on public.word_battle_teams for all to anon, authenticated using (true) with check (true);
create policy "word battle members all" on public.word_battle_members for all to anon, authenticated using (true) with check (true);
create policy "word battle entries all" on public.word_battle_entries for all to anon, authenticated using (true) with check (true);

do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'word_battle_settings') then
    alter publication supabase_realtime add table public.word_battle_settings;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'word_battle_teams') then
    alter publication supabase_realtime add table public.word_battle_teams;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'word_battle_members') then
    alter publication supabase_realtime add table public.word_battle_members;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'word_battle_entries') then
    alter publication supabase_realtime add table public.word_battle_entries;
  end if;
end $$;

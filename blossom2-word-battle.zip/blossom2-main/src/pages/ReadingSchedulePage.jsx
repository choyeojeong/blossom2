// src/pages/ReadingSchedulePage.jsx
import { useEffect, useMemo, useRef, useState } from "react";
import dayjs from "dayjs";
import "dayjs/locale/ko";
import { supabase } from "../utils/supabaseClient";

dayjs.locale("ko");

const COLORS = {
  bgTop: "#eef4ff",
  bgBottom: "#f7f9fc",
  text: "#1f2a44",
  sub: "#5d6b82",
  border: "#d9e3f7",
  white: "#ffffff",

  presentBg: "rgba(47,111,237,0.10)",
  presentBd: "rgba(47,111,237,0.35)",
  absentBg: "rgba(224,49,49,0.08)",
  absentBd: "rgba(224,49,49,0.30)",

  makeupBg: "rgba(250, 176, 5, 0.18)",
  makeupBd: "rgba(250, 176, 5, 0.40)",

  presentBtnBg: "rgba(47,111,237,0.12)",
  presentBtnBd: "rgba(47,111,237,0.35)",
  absentBtnBg: "rgba(224,49,49,0.10)",
  absentBtnBd: "rgba(224,49,49,0.32)",

  dangerBg: "rgba(224,49,49,0.08)",
  dangerBd: "rgba(224,49,49,0.28)",
};

function pad2(n) {
  return String(n).padStart(2, "0");
}

function hhmm(t) {
  const s = (t || "").toString();
  if (!s) return "";
  if (/^\d{2}:\d{2}:\d{2}$/.test(s)) return s.slice(0, 5);
  if (/^\d{2}:\d{2}$/.test(s)) return s;
  return s;
}

function clampTimeHHMM(v) {
  const s = (v || "").trim();
  if (!s) return "";
  const m = s.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return s;
  let hh = parseInt(m[1], 10);
  let mm = parseInt(m[2], 10);
  if (Number.isNaN(hh) || Number.isNaN(mm)) return s;
  hh = Math.max(0, Math.min(23, hh));
  mm = Math.max(0, Math.min(59, mm));
  return `${pad2(hh)}:${pad2(mm)}`;
}

function isValidHHMM(v) {
  const s = (v || "").trim();
  const m = s.match(/^(\d{2}):(\d{2})$/);
  if (!m) return false;
  const hh = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  return hh >= 0 && hh <= 23 && mm >= 0 && mm <= 59;
}

function presentWindow(attendedAtIso) {
  if (!attendedAtIso) return "";
  const a = dayjs(attendedAtIso);
  const b = a.add(90, "minute");
  return `${a.format("HH:mm")}-${b.format("HH:mm")}`;
}

function makeLocalDateTime(dateStr, timeStrHHMM) {
  const d = String(dateStr || "").trim();
  const t = hhmm(timeStrHHMM);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return null;
  if (!/^\d{2}:\d{2}$/.test(t)) return null;

  const [Y, M, D] = d.split("-").map((x) => parseInt(x, 10));
  const [h, m] = t.split(":").map((x) => parseInt(x, 10));
  if (!Y || !M || !D) return null;

  const dt = new Date(Y, M - 1, D, h || 0, m || 0, 0, 0);
  return Number.isNaN(dt.getTime()) ? null : dt;
}

function calcLateFromAttendedAt(eventDate, startTime, attendedAtIso) {
  const scheduled = makeLocalDateTime(eventDate, startTime);
  const attended = attendedAtIso ? new Date(attendedAtIso) : null;
  if (!scheduled || !attended || Number.isNaN(attended.getTime())) return null;

  const diffMin = Math.floor((attended.getTime() - scheduled.getTime()) / 60000);
  return Math.max(0, diffMin);
}

function calcLateFromNow(eventDate, startTime) {
  const scheduled = makeLocalDateTime(eventDate, startTime);
  if (!scheduled) return 0;
  const now = new Date();
  const diffMin = Math.floor((now.getTime() - scheduled.getTime()) / 60000);
  return Math.max(0, diffMin);
}

function seasonForDate(d) {
  const s = (d || "").trim();
  if (!s) return "term";
  const x = dayjs(s);
  if (!x.isValid()) return "term";
  const start = dayjs("2026-01-12");
  const end = dayjs("2026-02-28");
  if ((x.isAfter(start, "day") || x.isSame(start, "day")) && (x.isBefore(end, "day") || x.isSame(end, "day"))) {
    return "winter";
  }
  return "term";
}

function formatMessageDateTime(dateStr, timeStr) {
  const d = String(dateStr || "").trim();
  const t = hhmm(timeStr);
  if (!d) return t || "";

  const x = dayjs(d);
  if (!x.isValid()) return [d, t].filter(Boolean).join(" ");

  return `${x.format("M/D(dd)")} ${t}`.trim();
}

function buildAbsentMessage({ studentName, reason, classLabel, makeupDate, makeupTime }) {
  const safeName = String(studentName || "").trim() || "[학생명]";
  const safeReason = String(reason || "").trim() || "[결석사유]";
  const safeClassLabel = String(classLabel || "").trim() || "[수업유형]";
  const makeupText = formatMessageDateTime(makeupDate, makeupTime);

  const lines = [
    "안녕하세요, 블라썸에듀 영어학원입니다.",
    `${safeName} 학생 오늘 ${safeReason}으로 인해 ${safeClassLabel}수업 결석 연락 받았습니다.`,
  ];

  if (makeupText) {
    lines.push(`보강은 ${makeupText}에 진행될 예정입니다.`);
  }

  lines.push(
    "",
    "",
    "{블라썸에듀 결석 및 보강 규칙}",
    "본원에서는 선생님의 원활한 수업준비 및 학생들의 약속 준수를 장려하기 위해 아래와 같은 규칙을 적용하고 있습니다.",
    "1. 원칙적으로 당일 결석은 보강이 불가능합니다.",
    "단, 예외적으로 당일에 조율하기 어렵다고 판단되는 사유(예. 병결, 경조사)에 대해서는 보강을 제공합니다.",
    "2. 보강에 대한 재보강은 어떠한 사유로도 불가능합니다.",
    "**아이가 제시간을 지키고 사전에 보강을 조율할 수 있도록 가정에서도 많은 응원과 지도 부탁드립니다.",
    "",
    "",
    "감사합니다.",
    "산본 블라썸에듀) 031-393-0582"
  );

  return lines.join("\n");
}

function isWordTestTodo(text) {
  const parts = String(text || "")
    .split(",")
    .map((part) => part.trim());
  if (parts.length !== 5) return false;
  const questionOk = /^(\d+)\s*문제$/.test(parts[2]);
  const cutoffOk = /^-?(\d+)\s*컷$/.test(parts[3]);
  const allowedKinds = new Set(["뜻", "스펠링", "파포"]);
  const kinds = parts[4].split("/").map((x) => x.trim()).filter(Boolean);
  return Boolean(parts[0] && parts[1] && questionOk && cutoffOk && kinds.length && kinds.every((x) => allowedKinds.has(x)));
}

export default function ReadingSchedulePage() {
  const [date, setDate] = useState(() => dayjs().format("YYYY-MM-DD"));
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [rows, setRows] = useState([]);

  const [originalMap, setOriginalMap] = useState({});

  const [memoDraftById, setMemoDraftById] = useState({});
  const [memoSavingId, setMemoSavingId] = useState(null);

  const [absentOpen, setAbsentOpen] = useState(false);
  const [target, setTarget] = useState(null);
  const [absentReason, setAbsentReason] = useState("");
  const [makeupDate, setMakeupDate] = useState("");
  const [makeupClassTime, setMakeupClassTime] = useState("");
  const firstInputRef = useRef(null);

  const [addName, setAddName] = useState("");
  const [addDate, setAddDate] = useState(() => dayjs().format("YYYY-MM-DD"));
  const [addTime, setAddTime] = useState("");
  const [adding, setAdding] = useState(false);
  const [messageOpenId, setMessageOpenId] = useState(null);
  const [copiedMessageId, setCopiedMessageId] = useState(null);

  const [otoTodoOpen, setOtoTodoOpen] = useState(false);
  const [otoTodoTarget, setOtoTodoTarget] = useState(null);
  const [otoTodoDate, setOtoTodoDate] = useState("");
  const [otoTodos, setOtoTodos] = useState([]);
  const [otoTodoLoading, setOtoTodoLoading] = useState(false);
  const [otoTodoErr, setOtoTodoErr] = useState("");

  useEffect(() => {
    if (absentOpen) setTimeout(() => firstInputRef.current?.focus?.(), 0);
  }, [absentOpen]);

  const titleText = useMemo(() => {
    const d = dayjs(date);
    return `${d.format("YYYY.MM.DD")} (${d.format("ddd")})`;
  }, [date]);

  function isMakeupRow(r) {
    return r.kind === "extra" && (r.event_kind || "") === "makeup";
  }

  function rowTone(r) {
    if (r.attendance_status === "present") return { bg: COLORS.presentBg, bd: COLORS.presentBd };
    if (r.attendance_status === "absent") return { bg: COLORS.absentBg, bd: COLORS.absentBd };
    if (isMakeupRow(r)) return { bg: COLORS.makeupBg, bd: COLORS.makeupBd };
    return { bg: "transparent", bd: "transparent" };
  }

  async function load() {
    try {
      setErr("");
      setLoading(true);

      const { data, error } = await supabase
        .from("student_events")
        .select(
          `
          id,
          student_id,
          event_date,
          kind,
          start_time,
          season,
          schedule_kind,
          attendance_status,
          attended_at,
          late_minutes,
          absent_reason,
          makeup_date,
          makeup_class_time,
          class_minutes,
          original_event_id,
          makeup_event_id,
          event_kind,
          memo,
          student:students (
            id,
            name,
            school,
            grade,
            teacher_name
          )
        `
        )
        .eq("event_date", date)
        .or(["kind.eq.reading", "and(kind.eq.extra,event_kind.eq.makeup,schedule_kind.eq.reading)"].join(","));

      if (error) throw error;

      const filtered = (data || []).filter((r) => {
        if (r.kind === "reading") return true;
        if (r.kind === "extra" && (r.event_kind || "") === "makeup" && (r.schedule_kind || "") === "reading") return true;
        return false;
      });

      const normalized = filtered.map((r) => ({
        ...r,
        student_name: (r.student?.name || "").trim(),
        school: (r.student?.school || "").trim(),
        grade: (r.student?.grade || "").trim(),
        teacher_name: (r.student?.teacher_name || "").trim(),
        start_hhmm: hhmm(r.start_time),
      }));

      normalized.sort((a, b) => {
        const ta = makeLocalDateTime(a.event_date, a.start_time)?.getTime() ?? 9e18;
        const tb = makeLocalDateTime(b.event_date, b.start_time)?.getTime() ?? 9e18;
        if (ta !== tb) return ta - tb;
        return (a.student_name || "").localeCompare(b.student_name || "", "ko");
      });

      setRows(normalized);

      setMemoDraftById((prev) => {
        const next = { ...prev };
        for (const r of normalized) {
          if (next[r.id] === undefined) next[r.id] = r.memo || "";
        }
        return next;
      });

      try {
        const originIds = Array.from(
          new Set(
            normalized
              .filter((e) => e.kind === "extra" && (e.event_kind || "") === "makeup" && e.original_event_id)
              .map((e) => String(e.original_event_id))
          )
        ).filter(Boolean);

        if (originIds.length === 0) {
          setOriginalMap({});
        } else {
          const { data: origins, error: oErr } = await supabase
            .from("student_events")
            .select("id, event_date, absent_reason")
            .in("id", originIds);

          if (oErr) throw oErr;

          const m = {};
          for (const r of origins || []) {
            m[String(r.id)] = { id: r.id, event_date: r.event_date, absent_reason: r.absent_reason };
          }
          setOriginalMap(m);
        }
      } catch {
        setOriginalMap((prev) => prev || {});
      }
    } catch (e) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  async function markPresent(r) {
    try {
      setErr("");

      const isMakeup = isMakeupRow(r);
      const late = calcLateFromNow(r.event_date, r.start_time);

      const payload = isMakeup
        ? {
            attendance_status: "present",
            attended_at: new Date().toISOString(),
            late_minutes: late,
            absent_reason: null,
          }
        : {
            attendance_status: "present",
            attended_at: new Date().toISOString(),
            late_minutes: late,
            absent_reason: null,
            makeup_date: null,
            makeup_time: null,
            makeup_class_time: null,
          };

      const { error } = await supabase.from("student_events").update(payload).eq("id", r.id);

      if (error) throw error;
      await load();
    } catch (e) {
      setErr(e?.message || String(e));
    }
  }

  function openAbsent(r) {
    setTarget(r);
    setAbsentReason("");
    setMakeupDate("");
    setMakeupClassTime("");
    setAbsentOpen(true);
  }

  async function saveAbsent() {
    const r = target;
    if (!r) return;

    const mct = clampTimeHHMM(makeupClassTime);

    if ((makeupDate && !mct) || (!makeupDate && mct)) {
      setErr("보강일과 보강 수업시간(HH:MM)은 둘 다 입력해야 해요.");
      return;
    }
    if (mct && !isValidHHMM(mct)) {
      setErr("보강 수업시간은 HH:MM 형식으로 입력해줘. 예) 16:30");
      return;
    }

    try {
      setErr("");

      const { error: upErr } = await supabase
        .from("student_events")
        .update({
          attendance_status: "absent",
          attended_at: null,
          late_minutes: null,
          absent_reason: (absentReason || "").trim() || null,
          makeup_date: r.kind === "reading" ? (makeupDate || null) : null,
          makeup_class_time: r.kind === "reading" ? (mct || null) : null,
        })
        .eq("id", r.id);

      if (upErr) throw upErr;

      if (r.kind === "reading" && makeupDate && mct) {
        const dur = Number.isFinite(r.class_minutes) && r.class_minutes ? r.class_minutes : 60;
        const targetStartTime = `${mct}:00`;

        let existingMakeupId = r.makeup_event_id || null;

        if (!existingMakeupId) {
          const { data: ex, error: exErr } = await supabase
            .from("student_events")
            .select("id")
            .eq("original_event_id", r.id)
            .eq("kind", "extra")
            .eq("event_kind", "makeup")
            .eq("schedule_kind", "reading")
            .maybeSingle();
          if (exErr) throw exErr;
          existingMakeupId = ex?.id || null;
        }

        const insertPayload = {
          student_id: r.student_id,
          event_date: makeupDate,
          kind: "extra",
          start_time: targetStartTime,
          season: r.season,
          schedule_kind: "reading",
          attendance_status: null,
          attended_at: null,
          late_minutes: null,
          absent_reason: null,
          class_minutes: dur,
          original_event_id: r.id,
          event_kind: "makeup",
          makeup_class_time: mct,
        };

        const { data: dup, error: dupErr } = await supabase
          .from("student_events")
          .select("id, original_event_id")
          .eq("student_id", r.student_id)
          .eq("event_date", makeupDate)
          .eq("kind", "extra")
          .eq("event_kind", "makeup")
          .eq("start_time", targetStartTime)
          .eq("schedule_kind", "reading")
          .maybeSingle();

        if (dupErr) throw dupErr;

        if (dup && dup.original_event_id && dup.original_event_id !== r.id) {
          throw new Error("같은 날짜/시간에 이미 다른 결석과 연결된 보강이 있어요.");
        }

        if (existingMakeupId) {
          if (dup && dup.id !== existingMakeupId) {
            const { error: delOldErr } = await supabase
              .from("student_events")
              .delete()
              .eq("id", existingMakeupId);
            if (delOldErr) throw delOldErr;

            const { error: reuseErr } = await supabase
              .from("student_events")
              .update(insertPayload)
              .eq("id", dup.id);
            if (reuseErr) throw reuseErr;

            const { error: linkErr } = await supabase
              .from("student_events")
              .update({ makeup_event_id: dup.id })
              .eq("id", r.id);
            if (linkErr) throw linkErr;
          } else if (dup && dup.id === existingMakeupId) {
            const { error: upMuErr } = await supabase
              .from("student_events")
              .update(insertPayload)
              .eq("id", existingMakeupId);
            if (upMuErr) throw upMuErr;

            const { error: linkErr } = await supabase
              .from("student_events")
              .update({ makeup_event_id: existingMakeupId })
              .eq("id", r.id);
            if (linkErr) throw linkErr;
          } else {
            const { error: upMuErr } = await supabase
              .from("student_events")
              .update(insertPayload)
              .eq("id", existingMakeupId);
            if (upMuErr) throw upMuErr;

            const { error: linkErr } = await supabase
              .from("student_events")
              .update({ makeup_event_id: existingMakeupId })
              .eq("id", r.id);
            if (linkErr) throw linkErr;
          }
        } else {
          if (dup) {
            const { error: reuseErr } = await supabase
              .from("student_events")
              .update(insertPayload)
              .eq("id", dup.id);
            if (reuseErr) throw reuseErr;

            const { error: linkErr } = await supabase
              .from("student_events")
              .update({ makeup_event_id: dup.id })
              .eq("id", r.id);
            if (linkErr) throw linkErr;
          } else {
            const { data: insData, error: insErr } = await supabase
              .from("student_events")
              .insert(insertPayload)
              .select("id")
              .single();
            if (insErr) throw insErr;

            const { error: linkErr } = await supabase
              .from("student_events")
              .update({ makeup_event_id: insData?.id || null })
              .eq("id", r.id);
            if (linkErr) throw linkErr;
          }
        }
      }

      setAbsentOpen(false);
      setTarget(null);
      await load();
    } catch (e) {
      setErr(e?.message || String(e));
    }
  }

  async function resetAttendance(r) {
    const ok = window.confirm(
      `${r?.student_name || "이 학생"}의 출결 체크를 초기화할까요?\n\n초기화하면 현재 출석/결석 기록과 관련 정보가 삭제됩니다.`
    );
    if (!ok) return;

    try {
      setErr("");

      if (r.kind === "reading") {
        if (r.makeup_event_id) {
          const { error: delErr } = await supabase.from("student_events").delete().eq("id", r.makeup_event_id);
          if (delErr) throw delErr;
        }

        const { error: upErr } = await supabase
          .from("student_events")
          .update({
            attendance_status: null,
            attended_at: null,
            late_minutes: null,
            absent_reason: null,
            makeup_date: null,
            makeup_time: null,
            makeup_class_time: null,
            makeup_event_id: null,
          })
          .eq("id", r.id);

        if (upErr) throw upErr;
        await load();
        return;
      }

      const { error } = await supabase
        .from("student_events")
        .update({
          attendance_status: null,
          attended_at: null,
          late_minutes: null,
          absent_reason: null,
        })
        .eq("id", r.id);

      if (error) throw error;
      await load();
    } catch (e) {
      setErr(e?.message || String(e));
    }
  }

  async function saveMemo(rowId) {
    setMemoSavingId(rowId);
    setErr("");
    try {
      const raw = memoDraftById[rowId] ?? "";
      const memo = String(raw).trim();

      const { error } = await supabase.from("student_events").update({ memo: memo ? memo : null }).eq("id", rowId);
      if (error) throw error;
    } catch (e) {
      setErr(e?.message || String(e));
    } finally {
      setMemoSavingId(null);
    }
  }

  function autosizeTextarea(el) {
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }

  function getMakeupOriginLine(r) {
    if (!isMakeupRow(r)) return "";
    if (!r.original_event_id) return "";

    const origin = originalMap[String(r.original_event_id)] || null;
    if (!origin) return "원결석: (정보 로딩 실패)";

    const d = origin.event_date || "-";
    const reason = origin.absent_reason ? ` (사유: ${origin.absent_reason})` : "";
    return `원결석: ${d}${reason}`;
  }

  function renderAttendanceCell(r) {
    const status = r.attendance_status || null;

    if (status === "present") {
      const win = presentWindow(r.attended_at);

      const stored = r.late_minutes;
      const storedNum = stored === null || stored === undefined ? null : Number(stored);
      const computed = calcLateFromAttendedAt(r.event_date, r.start_time, r.attended_at);

      let lateForShow = 0;
      if (Number.isFinite(storedNum) && storedNum > 0) lateForShow = storedNum;
      else if (Number.isFinite(computed) && computed > 0) lateForShow = computed;
      else lateForShow = 0;

      const lateText = lateForShow <= 0 ? "정시 출석" : `지각 ${lateForShow}분`;
      const originLine = getMakeupOriginLine(r);

      return (
        <div style={styles.attnBox}>
          <div style={styles.attnLine1}>{win || "출석"}</div>
          <div style={styles.attnLine2}>{lateText}</div>
          {originLine ? <div style={styles.attnLine3}>{originLine}</div> : null}
        </div>
      );
    }

    if (status === "absent") {
      const line1 = r.absent_reason ? `결석 (${r.absent_reason})` : "결석";
      const line2 =
        r.kind === "reading" && r.makeup_date && r.makeup_class_time ? `보강 ${dayjs(r.makeup_date).format("MM.DD")} ${r.makeup_class_time}` : "";
      const originLine = getMakeupOriginLine(r);

      return (
        <div style={styles.attnBox}>
          <div style={styles.attnLine1}>{line1}</div>
          <div style={styles.attnLine2}>{line2}</div>
          {originLine ? <div style={styles.attnLine3}>{originLine}</div> : null}

          <div style={styles.messageBtnRow}>
            <button type="button" onClick={() => toggleMessageBox(r.id)} style={styles.btnPresent}>
              {messageOpenId === r.id ? "메시지 닫기" : "메시지 생성"}
            </button>
            {messageOpenId === r.id ? (
              <button type="button" onClick={() => copyMessageText(r)} style={styles.ghostBtn}>
                복사하기
              </button>
            ) : null}
          </div>

          {copiedMessageId === r.id ? <div style={styles.copyDone}>복사완료</div> : null}

          {messageOpenId === r.id ? (
            <textarea
              readOnly
              value={getMessageTextForRow(r)}
              rows={9}
              style={styles.messagePreview}
            />
          ) : null}
        </div>
      );
    }

    const originLine = getMakeupOriginLine(r);

    return (
      <div style={{ width: "100%", display: "grid", gap: 6, justifyItems: "center" }}>
        <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
          <button type="button" onClick={() => markPresent(r)} style={styles.btnPresent}>
            출석
          </button>
          <button type="button" onClick={() => openAbsent(r)} style={styles.btnAbsent}>
            결석
          </button>
        </div>
        {originLine ? <div style={styles.attnLine3}>{originLine}</div> : null}
      </div>
    );
  }

  function getMessageTextForRow(r) {
    if (!r) return "";

    return buildAbsentMessage({
      studentName: r.student_name || "",
      reason: r.absent_reason || "",
      classLabel: isMakeupRow(r) ? "독해 보강 " : "독해 ",
      makeupDate: r.kind === "reading" ? r.makeup_date || "" : "",
      makeupTime: r.kind === "reading" ? r.makeup_class_time || "" : "",
    });
  }

  function toggleMessageBox(rowId) {
    setCopiedMessageId((prev) => (prev === rowId ? null : prev));
    setMessageOpenId((prev) => (prev === rowId ? null : rowId));
  }

  async function copyMessageText(r) {
    try {
      await navigator.clipboard.writeText(getMessageTextForRow(r));
      setCopiedMessageId(r.id);
      window.setTimeout(() => {
        setCopiedMessageId((prev) => (prev === r.id ? null : prev));
      }, 1600);
    } catch (e) {
      setErr(e?.message || String(e));
    }
  }

  function closeOtoTodoModal() {
    setOtoTodoOpen(false);
    setOtoTodoTarget(null);
    setOtoTodoDate("");
    setOtoTodos([]);
    setOtoTodoErr("");
  }

  async function openOtoTodoModal(r) {
    if (!r?.student_id) return;

    setOtoTodoOpen(true);
    setOtoTodoTarget(r);
    setOtoTodoDate("");
    setOtoTodos([]);
    setOtoTodoErr("");
    setOtoTodoLoading(true);

    try {
      const upperDate = r.event_date || date;
      const otoKinds = ["oto", "oto_class", "one_to_one"];

      const [
        { data: kindRows, error: kindErr },
        { data: eventKindRows, error: eventKindErr },
        { data: makeupRows, error: makeupErr },
      ] = await Promise.all([
        supabase
          .from("student_events")
          .select("id,event_date,kind,event_kind,schedule_kind,original_event_id,attendance_status")
          .eq("student_id", r.student_id)
          .lte("event_date", upperDate)
          .in("kind", otoKinds)
          .order("event_date", { ascending: false })
          .limit(20),
        supabase
          .from("student_events")
          .select("id,event_date,kind,event_kind,schedule_kind,original_event_id,attendance_status")
          .eq("student_id", r.student_id)
          .lte("event_date", upperDate)
          .in("event_kind", otoKinds)
          .order("event_date", { ascending: false })
          .limit(20),
        supabase
          .from("student_events")
          .select("id,event_date,kind,event_kind,schedule_kind,original_event_id,attendance_status")
          .eq("student_id", r.student_id)
          .lte("event_date", upperDate)
          .eq("event_kind", "makeup")
          .order("event_date", { ascending: false })
          .limit(50),
      ]);

      if (kindErr) throw kindErr;
      if (eventKindErr) throw eventKindErr;
      if (makeupErr) throw makeupErr;

      const possibleMakeups = makeupRows || [];
      const originIds = Array.from(
        new Set(possibleMakeups.map((item) => item?.original_event_id).filter(Boolean).map(String))
      );

      let otoOriginIdSet = new Set();

      if (originIds.length) {
        const { data: originRows, error: originErr } = await supabase
          .from("student_events")
          .select("id,kind,event_kind,schedule_kind")
          .in("id", originIds);

        if (originErr) throw originErr;

        otoOriginIdSet = new Set(
          (originRows || [])
            .filter((item) => {
              const kind = String(item?.kind || "").toLowerCase();
              const eventKind = String(item?.event_kind || "").toLowerCase();
              const scheduleKind = String(item?.schedule_kind || "").toLowerCase();
              return otoKinds.includes(kind) || otoKinds.includes(eventKind) || otoKinds.includes(scheduleKind);
            })
            .map((item) => String(item.id))
        );
      }

      const otoMakeupRows = possibleMakeups.filter((item) => {
        const scheduleKind = String(item?.schedule_kind || "").toLowerCase();
        const kind = String(item?.kind || "").toLowerCase();
        const eventKind = String(item?.event_kind || "").toLowerCase();
        const originalId = item?.original_event_id ? String(item.original_event_id) : "";

        return (
          otoKinds.includes(scheduleKind) ||
          eventKind.includes("oto") ||
          eventKind.includes("one_to_one") ||
          kind === "makeup_oto" ||
          otoOriginIdSet.has(originalId)
        );
      });

      const eventMap = new Map();
      for (const item of [...(kindRows || []), ...(eventKindRows || []), ...otoMakeupRows]) {
        if (!item?.id || !item?.event_date) continue;

        // 결석 처리된 일대일 수업/보강은 "실제로 진행된 최근 수업"에서 제외한다.
        if (String(item?.attendance_status || "").toLowerCase() === "absent") continue;

        eventMap.set(String(item.id), item);
      }

      const latestEvent = Array.from(eventMap.values()).sort((a, b) => {
        const dateDiff = String(b.event_date).localeCompare(String(a.event_date));
        if (dateDiff !== 0) return dateDiff;
        return String(b.id).localeCompare(String(a.id));
      })[0];

      if (!latestEvent?.event_date) {
        setOtoTodoErr("최근 일대일 수업 또는 일대일 보강일을 찾지 못했어요.");
        return;
      }

      const latestDate = latestEvent.event_date;
      setOtoTodoDate(latestDate);

      const { data: todoRows, error: todoErr } = await supabase
        .from("student_todos")
        .select("id,todo_date,text,order_index,created_at")
        .eq("student_id", r.student_id)
        .eq("todo_date", latestDate)
        .order("order_index", { ascending: true })
        .order("created_at", { ascending: true });

      if (todoErr) throw todoErr;

      setOtoTodos((todoRows || []).filter((todo) => !isWordTestTodo(todo.text)));
    } catch (e) {
      setOtoTodoErr(e?.message || String(e));
    } finally {
      setOtoTodoLoading(false);
    }
  }

  async function findStudentIdByName(nameRaw) {
    const name = (nameRaw || "").trim();
    if (!name) return { id: null, pickedName: "" };

    {
      const { data, error } = await supabase.from("students").select("id,name").eq("name", name).limit(1);
      if (error) throw error;
      if (data && data.length) return { id: data[0].id, pickedName: data[0].name };
    }

    {
      const { data, error } = await supabase.from("students").select("id,name").ilike("name", `%${name}%`).limit(5);
      if (error) throw error;
      if (!data || data.length === 0) return { id: null, pickedName: "" };
      const sorted = [...data].sort((a, b) => (a.name || "").length - (b.name || "").length);
      return { id: sorted[0].id, pickedName: sorted[0].name };
    }
  }

  async function addMakeupDirect() {
    const nm = (addName || "").trim();
    const d = (addDate || "").trim();
    const t = clampTimeHHMM(addTime);

    if (!nm) {
      setErr("학생이름을 입력해줘.");
      return;
    }
    if (!d) {
      setErr("보강일을 선택해줘.");
      return;
    }
    if (!t || !isValidHHMM(t)) {
      setErr("보강 수업시간은 HH:MM 형식으로 입력해줘. 예) 16:30");
      return;
    }

    try {
      setErr("");
      setAdding(true);

      const found = await findStudentIdByName(nm);
      if (!found.id) {
        setErr(`학생을 찾지 못했어요: "${nm}"`);
        return;
      }

      const targetStartTime = `${t}:00`;

      const { data: dup, error: dupErr } = await supabase
        .from("student_events")
        .select("id")
        .eq("student_id", found.id)
        .eq("event_date", d)
        .eq("kind", "extra")
        .eq("event_kind", "makeup")
        .eq("start_time", targetStartTime)
        .maybeSingle();

      if (dupErr) throw dupErr;

      if (dup) {
        throw new Error("이미 같은 날짜/시간의 보강이 등록되어 있어요.");
      }

      const payload = {
        student_id: found.id,
        event_date: d,
        kind: "extra",
        event_kind: "makeup",
        schedule_kind: "reading",
        start_time: targetStartTime,
        season: seasonForDate(d),
        attendance_status: null,
        attended_at: null,
        late_minutes: null,
        absent_reason: null,
        class_minutes: 60,
        original_event_id: null,
        makeup_class_time: t,
      };

      const { error } = await supabase.from("student_events").insert(payload);
      if (error) throw error;

      setAddName("");
      setAddTime("");
      setDate(d);
    } catch (e) {
      setErr(e?.message || String(e));
    } finally {
      setAdding(false);
    }
  }

  async function deleteRow(r) {
    if (!r?.id) return;
    const ok = window.confirm("이 줄을 삭제할까요? (되돌릴 수 없어요)");
    if (!ok) return;

    try {
      setErr("");

      if (isMakeupRow(r) && r.original_event_id) {
        const { error: upErr } = await supabase
          .from("student_events")
          .update({
            makeup_date: null,
            makeup_time: null,
            makeup_class_time: null,
            makeup_event_id: null,
          })
          .eq("id", r.original_event_id);

        if (upErr) throw upErr;
      }

      const { error } = await supabase.from("student_events").delete().eq("id", r.id);
      if (error) throw error;

      await load();
    } catch (e) {
      setErr(e?.message || String(e));
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.wrap}>
        <div style={styles.headRow}>
          <div>
            <div style={styles.title}>독해 시간표</div>
            <div style={styles.subtitle}>{titleText}</div>
          </div>

          <div style={styles.headRight}>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={styles.date} />
            <button type="button" onClick={load} style={styles.ghostBtn}>
              새로고침
            </button>
          </div>
        </div>

        {err ? <div style={styles.error}>{err}</div> : null}

        <div style={styles.table}>
          <div style={styles.thead}>
            <div style={styles.thCenter}>번호</div>
            <div style={styles.thCenter}>시작</div>
            <div style={styles.thCenter}>학생이름</div>
            <div style={styles.thCenter}>학교</div>
            <div style={styles.thCenter}>학년</div>
            <div style={styles.thCenter}>담당선생님</div>
            <div style={styles.thCenter}>출결</div>
            <div style={styles.thCenter}>초기화</div>
            <div style={styles.thCenter}>메모</div>
            <div style={styles.thCenter}>삭제</div>
          </div>

          {loading ? (
            <div style={styles.empty}>불러오는 중…</div>
          ) : rows.length === 0 ? (
            <div style={styles.empty}>이 날짜에 독해 수업이 없어요.</div>
          ) : (
            rows.map((r, idx) => {
              const tone = rowTone(r);
              const isMakeup = isMakeupRow(r);
              const memoVal = memoDraftById[r.id] ?? (r.memo || "");
              const saving = memoSavingId === r.id;

              return (
                <div
                  key={r.id}
                  style={{
                    ...styles.tr,
                    background: tone.bg,
                    borderColor: tone.bd,
                  }}
                >
                  <div style={styles.tdCenter}>{idx + 1}</div>

                  <div style={styles.tdCenterStrong}>{r.start_hhmm || "-"}</div>

                  <div style={styles.tdCenterFlex}>
                    <div style={styles.ellipsisStrong}>{r.student_name || "-"}</div>
                    {isMakeup ? <span style={styles.badge}>보강</span> : null}
                  </div>

                  <div style={styles.tdCenter}>
                    <span style={styles.ellipsisSub}>{r.school || "-"}</span>
                  </div>

                  <div style={styles.tdCenter}>
                    <span style={{ fontWeight: 900, color: COLORS.sub }}>{r.grade || "-"}</span>
                  </div>

                  <div style={styles.tdCenter}>
                    <span style={styles.ellipsisSub}>{r.teacher_name || "-"}</span>
                  </div>

                  <div style={styles.tdCenter}>{renderAttendanceCell(r)}</div>

                  <div style={styles.tdCenter}>
                    <button type="button" onClick={() => resetAttendance(r)} style={styles.ghostBtn}>
                      초기화
                    </button>
                  </div>

                  <div style={{ ...styles.tdCenter, alignItems: "stretch" }}>
                    <div style={{ width: "100%" }}>
                      <textarea
                        value={memoVal}
                        onChange={(e) =>
                          setMemoDraftById((prev) => ({
                            ...prev,
                            [r.id]: e.target.value,
                          }))
                        }
                        onInput={(e) => autosizeTextarea(e.currentTarget)}
                        onFocus={(e) => autosizeTextarea(e.currentTarget)}
                        onBlur={(e) => {
                          autosizeTextarea(e.currentTarget);
                          saveMemo(r.id);
                        }}
                        placeholder="메모"
                        rows={1}
                        style={{
                          ...styles.memo,
                          opacity: saving ? 0.75 : 1,
                        }}
                        disabled={saving}
                      />
                      <div style={styles.memoBottomRow}>
                        <div style={styles.memoHint}>{saving ? "저장 중…" : ""}</div>
                        <button type="button" onClick={() => openOtoTodoModal(r)} style={styles.otoBtn}>
                          일대일
                        </button>
                      </div>
                    </div>
                  </div>

                  <div style={styles.tdCenter}>
                    <button type="button" onClick={() => deleteRow(r)} style={styles.btnDelete}>
                      삭제
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div style={styles.addBox}>
          <div style={styles.addTitle}>보강 추가</div>
          <div style={{ marginTop: 6, color: COLORS.sub, fontSize: 12, lineHeight: 1.45, fontWeight: 800 }}>
            • 이 화면에서 추가한 보강은 자동으로 <b>독해(reading)</b> 보강으로 저장돼요. (일대일 시간표에 섞이지 않음)
          </div>

          <div style={styles.addGrid}>
            <div>
              <div style={styles.label}>학생이름</div>
              <input value={addName} onChange={(e) => setAddName(e.target.value)} placeholder="예: 김민준" style={styles.input} />
            </div>

            <div>
              <div style={styles.label}>보강일</div>
              <input type="date" value={addDate} onChange={(e) => setAddDate(e.target.value)} style={styles.input} />
            </div>

            <div>
              <div style={styles.label}>보강 수업시간 HH:MM</div>
              <input value={addTime} onChange={(e) => setAddTime(clampTimeHHMM(e.target.value))} placeholder="예: 16:30" style={styles.input} />
            </div>

            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "flex-end" }}>
              <button type="button" onClick={addMakeupDirect} style={styles.btnAdd} disabled={adding}>
                {adding ? "추가 중…" : "보강 추가"}
              </button>
            </div>
          </div>

          <div style={styles.addHint}>
            • 원결석일 없이도 보강(추가) 수업을 직접 만들어요. <br />
            • 추가하면 해당 보강일로 화면이 이동해요.
          </div>
        </div>
      </div>

      {otoTodoOpen ? (
        <div
          role="dialog"
          aria-modal="true"
          onMouseDown={closeOtoTodoModal}
          style={styles.modalOverlay}
        >
          <div onMouseDown={(e) => e.stopPropagation()} style={styles.otoModal}>
            <div style={styles.modalHead}>
              <div style={{ minWidth: 0 }}>
                <div style={styles.otoModalTitle}>{otoTodoTarget?.student_name || "-"} · 최근 일대일 할일</div>
                <div style={styles.otoModalDate}>
                  {otoTodoDate ? dayjs(otoTodoDate).format("YYYY.MM.DD (ddd)") : "최근 수업일 확인 중"}
                </div>
              </div>
              <button type="button" onClick={closeOtoTodoModal} style={styles.closeXBtn} aria-label="닫기">
                ×
              </button>
            </div>

            <div style={styles.otoTodoBody}>
              {otoTodoLoading ? (
                <div style={styles.otoEmpty}>불러오는 중…</div>
              ) : otoTodoErr ? (
                <div style={styles.otoError}>{otoTodoErr}</div>
              ) : otoTodos.length === 0 ? (
                <div style={styles.otoEmpty}>등록된 일반 할일이 없어요.</div>
              ) : (
                <div style={styles.otoTodoList}>
                  {otoTodos.map((todo, idx) => (
                    <div key={todo.id} style={styles.otoTodoItem}>
                      <span style={styles.otoTodoNumber}>{idx + 1}</span>
                      <span style={styles.otoTodoText}>{todo.text}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {absentOpen ? (
        <div
          role="dialog"
          aria-modal="true"
          onMouseDown={() => {
            setAbsentOpen(false);
            setTarget(null);
          }}
          style={styles.modalOverlay}
        >
          <div onMouseDown={(e) => e.stopPropagation()} style={styles.modal}>
            <div style={styles.modalHead}>
              <div style={{ fontSize: 16, fontWeight: 900, color: COLORS.text }}>결석 처리: {target?.student_name || "-"}</div>
              <button
                type="button"
                onClick={() => {
                  setAbsentOpen(false);
                  setTarget(null);
                }}
                style={styles.ghostBtn}
              >
                닫기
              </button>
            </div>

            <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
              <div>
                <div style={styles.label}>결석 사유</div>
                <input
                  ref={firstInputRef}
                  value={absentReason}
                  onChange={(e) => setAbsentReason(e.target.value)}
                  placeholder="예: 감기 / 학교행사 / 개인사정"
                  style={styles.input}
                />
              </div>

              {target?.kind === "reading" ? (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div>
                    <div style={styles.label}>보강일 (선택)</div>
                    <input type="date" value={makeupDate} onChange={(e) => setMakeupDate(e.target.value)} style={styles.input} />
                  </div>

                  <div>
                    <div style={styles.label}>보강 수업시간 HH:MM (선택)</div>
                    <input
                      value={makeupClassTime}
                      onChange={(e) => setMakeupClassTime(clampTimeHHMM(e.target.value))}
                      placeholder="예: 16:30"
                      style={styles.input}
                    />
                  </div>
                </div>
              ) : (
                <div style={{ fontSize: 12, color: COLORS.sub, fontWeight: 800, lineHeight: 1.5 }}>
                  • 보강(추가) 수업은 여기서 “보강 생성”을 하지 않아요. 결석 사유만 저장돼요.
                </div>
              )}

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 6 }}>
                <button
                  type="button"
                  onClick={() => {
                    setAbsentOpen(false);
                    setTarget(null);
                  }}
                  style={styles.ghostBtn}
                >
                  취소
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (target?.kind === "reading" && makeupClassTime) {
                      const t = clampTimeHHMM(makeupClassTime);
                      if (!isValidHHMM(t)) {
                        setErr("보강 수업시간은 HH:MM 형식으로 입력해줘. 예) 16:30");
                        return;
                      }
                    }
                    saveAbsent();
                  }}
                  style={styles.btnAbsent}
                >
                  저장
                </button>
              </div>

              <div style={{ marginTop: 6, fontSize: 12, color: COLORS.sub, lineHeight: 1.5 }}>
                • 독해 보강은 테스트시간이 없어서 <b>수업시간만</b> 입력해요.<br />
                • 출석 누르면 출결 칸에 <b>출석체크 시각~90분</b>이 표시돼요.<br />
                • 보강은 출결 전엔 <b>연노랑</b>, 출결 처리하면 그때 색이 바뀌어요.
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

const GRID = "46px 66px 0.92fr 0.80fr 72px 110px 1.60fr 86px 1.18fr 78px";

const styles = {
  page: {
    minHeight: "100vh",
    background: `linear-gradient(180deg, ${COLORS.bgTop} 0%, ${COLORS.bgBottom} 60%, ${COLORS.bgBottom} 100%)`,
    padding: "22px 16px 90px",
    color: COLORS.text,
    fontFamily: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans KR"',
  },
  wrap: { maxWidth: 1280, margin: "0 auto" },

  headRow: {
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 14,
  },
  title: { fontSize: 22, fontWeight: 900, letterSpacing: -0.2 },
  subtitle: { marginTop: 6, color: COLORS.sub, fontSize: 13, fontWeight: 700 },

  headRight: { display: "flex", alignItems: "center", gap: 10 },
  date: {
    height: 38,
    padding: "0 10px",
    borderRadius: 12,
    border: `1px solid ${COLORS.border}`,
    background: "#fff",
    color: COLORS.text,
    fontWeight: 800,
  },

  error: {
    marginBottom: 12,
    border: "1px solid rgba(224,49,49,0.25)",
    background: "rgba(224,49,49,0.08)",
    color: "#b42318",
    padding: "10px 12px",
    borderRadius: 12,
    fontSize: 13,
    whiteSpace: "pre-wrap",
  },

  table: { display: "grid", gap: 8 },

  thead: {
    display: "grid",
    gridTemplateColumns: GRID,
    gap: 6,
    padding: "0 2px",
  },
  thCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 24,
    fontSize: 12,
    fontWeight: 900,
    color: COLORS.sub,
    textAlign: "center",
  },

  tr: {
    display: "grid",
    gridTemplateColumns: GRID,
    gap: 6,
    alignItems: "center",
    padding: "10px 10px",
    borderRadius: 16,
    border: "1px solid transparent",
    background: "rgba(255,255,255,0.35)",
    backdropFilter: "blur(6px)",
  },

  tdCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 32,
    overflow: "hidden",
  },
  tdCenterStrong: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 32,
    overflow: "hidden",
    fontWeight: 900,
    color: COLORS.text,
  },
  tdCenterFlex: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    minHeight: 32,
    overflow: "hidden",
  },

  ellipsisStrong: {
    maxWidth: "100%",
    fontWeight: 900,
    color: COLORS.text,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  ellipsisSub: {
    maxWidth: "100%",
    color: COLORS.sub,
    fontWeight: 800,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },

  badge: {
    fontSize: 11,
    padding: "2px 8px",
    borderRadius: 999,
    border: `1px solid ${COLORS.border}`,
    background: "rgba(255,255,255,0.75)",
    color: COLORS.sub,
    fontWeight: 900,
    flex: "0 0 auto",
  },

  btnPresent: {
    height: 32,
    padding: "0 12px",
    borderRadius: 999,
    border: `1px solid ${COLORS.presentBtnBd}`,
    background: COLORS.presentBtnBg,
    color: COLORS.text,
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },
  btnAbsent: {
    height: 32,
    padding: "0 12px",
    borderRadius: 999,
    border: `1px solid ${COLORS.absentBtnBd}`,
    background: COLORS.absentBtnBg,
    color: COLORS.text,
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },

  ghostBtn: {
    height: 32,
    padding: "0 12px",
    borderRadius: 999,
    border: `1px solid ${COLORS.border}`,
    background: "rgba(255,255,255,0.75)",
    color: COLORS.sub,
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },

  btnDelete: {
    height: 32,
    padding: "0 12px",
    borderRadius: 999,
    border: `1px solid ${COLORS.dangerBd}`,
    background: COLORS.dangerBg,
    color: "#b42318",
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },

  attnBox: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 2,
    overflow: "hidden",
  },
  attnLine1: {
    width: "100%",
    textAlign: "center",
    fontWeight: 900,
    fontSize: 13,
    color: COLORS.text,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    lineHeight: "18px",
  },
  attnLine2: {
    width: "100%",
    textAlign: "center",
    fontWeight: 800,
    fontSize: 12,
    color: COLORS.sub,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    lineHeight: "16px",
    minHeight: 16,
  },

  messageBtnRow: {
    marginTop: 8,
    display: "flex",
    justifyContent: "center",
    gap: 8,
    flexWrap: "wrap",
  },
  copyDone: {
    marginTop: 4,
    fontSize: 12,
    color: COLORS.sub,
    fontWeight: 900,
    textAlign: "center",
  },
  messagePreview: {
    width: "100%",
    marginTop: 8,
    resize: "vertical",
    padding: "10px 10px",
    borderRadius: 12,
    border: `1px solid ${COLORS.border}`,
    background: "#fff",
    color: COLORS.text,
    fontWeight: 800,
    fontSize: 12,
    lineHeight: "18px",
    outline: "none",
  },
  attnLine3: {
    width: "100%",
    textAlign: "center",
    fontWeight: 900,
    fontSize: 12,
    color: COLORS.sub,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    lineHeight: "16px",
    minHeight: 16,
    marginTop: 2,
  },

  memo: {
    width: "100%",
    minHeight: 32,
    height: 32,
    resize: "none",
    overflow: "hidden",
    padding: "7px 10px",
    borderRadius: 12,
    border: `1px solid ${COLORS.border}`,
    background: "#fff",
    color: COLORS.text,
    fontWeight: 800,
    fontSize: 13,
    lineHeight: "18px",
    outline: "none",
  },
  memoHint: {
    marginTop: 4,
    minHeight: 14,
    fontSize: 11,
    color: COLORS.sub,
    fontWeight: 800,
    textAlign: "center",
  },

  memoBottomRow: {
    minHeight: 22,
    marginTop: 4,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 6,
  },
  otoBtn: {
    height: 24,
    padding: "0 9px",
    borderRadius: 999,
    border: `1px solid ${COLORS.presentBtnBd}`,
    background: COLORS.presentBtnBg,
    color: COLORS.text,
    fontSize: 11,
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flex: "0 0 auto",
  },
  otoModal: {
    width: "min(480px, calc(100vw - 32px))",
    maxHeight: "min(560px, calc(100vh - 32px))",
    overflow: "hidden",
    borderRadius: 18,
    background: "#fff",
    border: `1px solid ${COLORS.border}`,
    padding: 16,
    boxShadow: "0 24px 70px rgba(31,42,68,0.24)",
  },
  otoModalTitle: {
    fontSize: 16,
    fontWeight: 900,
    color: COLORS.text,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  otoModalDate: { marginTop: 4, color: COLORS.sub, fontSize: 12, fontWeight: 800 },
  closeXBtn: {
    width: 32,
    height: 32,
    flex: "0 0 auto",
    borderRadius: 10,
    border: `1px solid ${COLORS.border}`,
    background: "#fff",
    color: COLORS.text,
    fontSize: 20,
    lineHeight: 1,
    fontWeight: 900,
    cursor: "pointer",
  },
  otoTodoBody: { marginTop: 14, maxHeight: "min(440px, calc(100vh - 130px))", overflowY: "auto", overflowX: "hidden" },
  otoTodoList: { display: "grid", gap: 8, minWidth: 0 },
  otoTodoItem: {
    display: "grid",
    gridTemplateColumns: "24px minmax(0, 1fr)",
    alignItems: "start",
    gap: 8,
    padding: "9px 10px",
    borderRadius: 12,
    border: `1px solid ${COLORS.border}`,
    background: "#f8faff",
    minWidth: 0,
  },
  otoTodoNumber: {
    width: 22,
    height: 22,
    borderRadius: 999,
    display: "grid",
    placeItems: "center",
    background: COLORS.presentBtnBg,
    color: COLORS.text,
    fontSize: 11,
    fontWeight: 900,
  },
  otoTodoText: {
    minWidth: 0,
    color: COLORS.text,
    fontSize: 13,
    lineHeight: 1.5,
    fontWeight: 800,
    whiteSpace: "pre-wrap",
    overflowWrap: "anywhere",
    wordBreak: "break-word",
  },
  otoEmpty: { padding: "18px 6px", textAlign: "center", color: COLORS.sub, fontSize: 13, fontWeight: 800 },
  otoError: { padding: "12px", borderRadius: 12, background: COLORS.dangerBg, color: "#b42318", fontSize: 13, fontWeight: 800, overflowWrap: "anywhere" },

  empty: {
    padding: 14,
    color: COLORS.sub,
    fontWeight: 800,
  },

  modalOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.25)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    zIndex: 9999,
  },
  modal: {
    width: "min(560px, 100%)",
    borderRadius: 18,
    background: "#fff",
    border: `1px solid ${COLORS.border}`,
    padding: 16,
  },
  modalHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  label: { fontSize: 12, fontWeight: 900, color: COLORS.sub, marginBottom: 6 },
  input: {
    width: "100%",
    height: 40,
    padding: "0 12px",
    borderRadius: 12,
    border: `1px solid ${COLORS.border}`,
    outline: "none",
    color: COLORS.text,
    fontWeight: 800,
    background: "#fff",
  },

  addBox: {
    marginTop: 18,
    border: `1px solid ${COLORS.border}`,
    background: "rgba(255,255,255,0.55)",
    borderRadius: 16,
    padding: 14,
  },
  addTitle: {
    fontSize: 14,
    fontWeight: 900,
    color: COLORS.text,
    marginBottom: 10,
  },
  addGrid: {
    display: "grid",
    gridTemplateColumns: "1.1fr 1fr 1fr auto",
    gap: 10,
    alignItems: "end",
  },
  btnAdd: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: `1px solid ${COLORS.presentBtnBd}`,
    background: COLORS.presentBtnBg,
    color: COLORS.text,
    fontWeight: 900,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },
  addHint: {
    marginTop: 10,
    fontSize: 12,
    color: COLORS.sub,
    fontWeight: 800,
    lineHeight: 1.5,
  },
};
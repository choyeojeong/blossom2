import { useEffect, useMemo, useState } from "react";
import dayjs from "dayjs";
import { supabase } from "../utils/supabaseClient";
import "./WordBattle.css";

const DEFAULT_SETTINGS = {
  id: 1,
  event_title: "중3 단어대전",
  event_subtitle: "단어를 쌓고, 팀의 기록을 높여라!",
  event_body: "2026. 9. 14. ~ 10. 31.\n매일의 통과가 우리 팀의 점수가 됩니다.",
  rules_title: "중3 단어대전 규칙",
  rules_body: "1. 단어시험에 통과한 범위의 단어만 인정됩니다.\n2. 학생별 통과 단어 수를 매일 누적합니다.\n3. 대전 종료일까지 가장 많은 단어를 쌓은 팀이 우승합니다.\n4. 정직하게, 끝까지, 함께 도전합니다!",
  intro_bg: "#173f8a",
  rules_bg: "#0f6b5d",
  accent_color: "#ffd34e",
  slide_seconds: 8,
  start_date: "2026-09-14",
  end_date: "2026-10-31",
};

const DEFAULT_TEAMS = [
  { name: "블루팀", color: "#3478f6", sort_order: 1 },
  { name: "레드팀", color: "#f05454", sort_order: 2 },
  { name: "그린팀", color: "#23a36d", sort_order: 3 },
  { name: "옐로팀", color: "#f2b632", sort_order: 4 },
];

export default function WordBattlePage() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [teams, setTeams] = useState([]);
  const [members, setMembers] = useState([]);
  const [entries, setEntries] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = dayjs().format("YYYY-MM-DD");
    if (today < DEFAULT_SETTINGS.start_date) return DEFAULT_SETTINGS.start_date;
    if (today > DEFAULT_SETTINGS.end_date) return DEFAULT_SETTINGS.end_date;
    return today;
  });
  const [counts, setCounts] = useState({});
  const [newNames, setNewNames] = useState({});
  const [studentChoices, setStudentChoices] = useState({});
  const [activeTab, setActiveTab] = useState("score");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadAll();
  }, []);

  useEffect(() => {
    const next = {};
    entries.filter((entry) => entry.entry_date === selectedDate).forEach((entry) => {
      next[entry.member_id] = entry.word_count;
    });
    setCounts(next);
  }, [entries, selectedDate]);

  async function loadAll() {
    setLoading(true);
    setError("");
    try {
      const [settingsRes, teamsRes, membersRes, entriesRes, studentsRes] = await Promise.all([
        supabase.from("word_battle_settings").select("*").eq("id", 1).maybeSingle(),
        supabase.from("word_battle_teams").select("*").order("sort_order"),
        supabase.from("word_battle_members").select("*").eq("is_active", true).order("name"),
        supabase.from("word_battle_entries").select("*").order("entry_date", { ascending: false }),
        supabase.from("students").select("id, name, school, grade").order("name"),
      ]);
      for (const result of [settingsRes, teamsRes, membersRes, entriesRes, studentsRes]) {
        if (result.error) throw result.error;
      }
      setSettings({ ...DEFAULT_SETTINGS, ...(settingsRes.data || {}) });
      setTeams(teamsRes.data || []);
      setMembers(membersRes.data || []);
      setEntries(entriesRes.data || []);
      setStudents(studentsRes.data || []);
    } catch (e) {
      setError(`${e?.message || "데이터를 불러오지 못했습니다."} Supabase SQL을 먼저 실행했는지 확인해주세요.`);
    } finally {
      setLoading(false);
    }
  }

  const totals = useMemo(() => {
    const memberTotals = {};
    entries.forEach((entry) => {
      memberTotals[entry.member_id] = (memberTotals[entry.member_id] || 0) + Number(entry.word_count || 0);
    });
    const teamTotals = {};
    members.forEach((member) => {
      teamTotals[member.team_id] = (teamTotals[member.team_id] || 0) + (memberTotals[member.id] || 0);
    });
    return { memberTotals, teamTotals };
  }, [entries, members]);

  function notify(text) {
    setMessage(text);
    window.setTimeout(() => setMessage(""), 2500);
  }

  async function createInitialData() {
    setBusy(true);
    setError("");
    try {
      const { error: settingsError } = await supabase.from("word_battle_settings").upsert(DEFAULT_SETTINGS);
      if (settingsError) throw settingsError;
      const { error: teamsError } = await supabase.from("word_battle_teams").insert(DEFAULT_TEAMS);
      if (teamsError) throw teamsError;
      await loadAll();
      notify("기본 설정과 4개 팀을 만들었습니다.");
    } catch (e) {
      setError(e?.message || "초기 데이터를 만들지 못했습니다.");
    } finally {
      setBusy(false);
    }
  }

  async function saveSettings() {
    setBusy(true);
    setError("");
    const payload = {
      ...settings,
      id: 1,
      slide_seconds: Math.min(60, Math.max(3, Number(settings.slide_seconds) || 8)),
      updated_at: new Date().toISOString(),
    };
    const { data, error: saveError } = await supabase
      .from("word_battle_settings")
      .upsert(payload)
      .select()
      .single();
    setBusy(false);
    if (saveError) return setError(saveError.message);
    setSettings(data);
    notify("화면 설정을 저장했습니다.");
  }

  async function saveTeam(team) {
    const { error: saveError } = await supabase
      .from("word_battle_teams")
      .update({ name: team.name.trim(), color: team.color, updated_at: new Date().toISOString() })
      .eq("id", team.id);
    if (saveError) return setError(saveError.message);
    notify("팀 설정을 저장했습니다.");
  }

  async function addMember(teamId) {
    const selectedId = studentChoices[teamId] || "";
    const selectedStudent = students.find((student) => student.id === selectedId);
    const name = (selectedStudent?.name || newNames[teamId] || "").trim();
    if (!name) return alert("학생을 선택하거나 이름을 입력해주세요.");
    const payload = { team_id: teamId, student_id: selectedStudent?.id || null, name, is_active: true };
    const { data, error: addError } = await supabase.from("word_battle_members").insert(payload).select().single();
    if (addError) return setError(addError.message);
    setMembers((prev) => [...prev, data].sort((a, b) => a.name.localeCompare(b.name, "ko")));
    setNewNames((prev) => ({ ...prev, [teamId]: "" }));
    setStudentChoices((prev) => ({ ...prev, [teamId]: "" }));
    notify(`${name} 학생을 등록했습니다.`);
  }

  async function removeMember(member) {
    if (!window.confirm(`${member.name} 학생을 팀에서 삭제할까요?\n기존 누적 기록도 함께 삭제됩니다.`)) return;
    const { error: deleteError } = await supabase.from("word_battle_members").delete().eq("id", member.id);
    if (deleteError) return setError(deleteError.message);
    setMembers((prev) => prev.filter((item) => item.id !== member.id));
    setEntries((prev) => prev.filter((item) => item.member_id !== member.id));
    notify("학생을 삭제했습니다.");
  }

  async function moveMember(member, teamId) {
    const { error: moveError } = await supabase.from("word_battle_members").update({ team_id: teamId }).eq("id", member.id);
    if (moveError) return setError(moveError.message);
    setMembers((prev) => prev.map((item) => item.id === member.id ? { ...item, team_id: teamId } : item));
    notify("소속 팀을 변경했습니다.");
  }

  async function saveDailyScores() {
    if (selectedDate < settings.start_date || selectedDate > settings.end_date) {
      return alert(`집계 기간(${settings.start_date} ~ ${settings.end_date}) 안의 날짜를 선택해주세요.`);
    }
    setBusy(true);
    setError("");
    try {
      const changed = members.map((member) => ({
        member_id: member.id,
        entry_date: selectedDate,
        word_count: Math.max(0, Number(counts[member.id]) || 0),
      }));
      const { data, error: saveError } = await supabase
        .from("word_battle_entries")
        .upsert(changed, { onConflict: "member_id,entry_date" })
        .select();
      if (saveError) throw saveError;
      setEntries((prev) => {
        const keys = new Set(changed.map((item) => `${item.member_id}|${item.entry_date}`));
        return [...prev.filter((item) => !keys.has(`${item.member_id}|${item.entry_date}`)), ...(data || [])];
      });
      notify(`${dayjs(selectedDate).format("M월 D일")} 기록을 저장했습니다.`);
    } catch (e) {
      setError(e?.message || "기록을 저장하지 못했습니다.");
    } finally {
      setBusy(false);
    }
  }

  function downloadCsv() {
    const rows = [["날짜", "팀", "학생", "통과 단어 수"]];
    entries.slice().sort((a, b) => a.entry_date.localeCompare(b.entry_date)).forEach((entry) => {
      const member = members.find((item) => item.id === entry.member_id);
      const team = teams.find((item) => item.id === member?.team_id);
      rows.push([entry.entry_date, team?.name || "", member?.name || "", entry.word_count]);
    });
    const csv = `\ufeff${rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n")}`;
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `중3단어대전_${dayjs().format("YYYYMMDD")}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  if (loading) return <div className="wb-loading">중3 단어대전 정보를 불러오는 중...</div>;

  if (!teams.length) {
    return <main className="wb-admin"><div className="wb-empty"><h1>중3 단어대전</h1><p>SQL 실행은 완료되었지만 팀 정보가 없습니다.</p><button disabled={busy} onClick={createInitialData}>기본 4팀 만들기</button>{error && <p className="wb-error">{error}</p>}</div></main>;
  }

  return (
    <main className="wb-admin">
      <header className="wb-admin-header">
        <div><span className="wb-eyebrow">BLOSSOM EDU</span><h1>중3 단어대전 관리</h1><p>{settings.start_date} ~ {settings.end_date}</p></div>
        <div className="wb-header-actions">
          <button className="wb-secondary" onClick={downloadCsv}>기록 CSV</button>
          <button onClick={() => window.open("/word-battle/display", "_blank")}>모니터 화면 열기 ↗</button>
        </div>
      </header>

      <nav className="wb-tabs">
        <button className={activeTab === "score" ? "active" : ""} onClick={() => setActiveTab("score")}>오늘의 단어 입력</button>
        <button className={activeTab === "members" ? "active" : ""} onClick={() => setActiveTab("members")}>팀·구성원 관리</button>
        <button className={activeTab === "slides" ? "active" : ""} onClick={() => setActiveTab("slides")}>안내·규칙 편집</button>
      </nav>

      {message && <div className="wb-toast">{message}</div>}
      {error && <div className="wb-error">{error}</div>}

      {activeTab === "score" && <>
        <section className="wb-summary-grid">
          {teams.map((team) => <article className="wb-summary" key={team.id} style={{ borderTopColor: team.color }}><span>{team.name}</span><strong>{(totals.teamTotals[team.id] || 0).toLocaleString()}</strong><small>누적 단어</small></article>)}
        </section>
        <section className="wb-card">
          <div className="wb-card-title"><div><h2>날짜별 통과 단어 수</h2><p>그날 시험에 통과한 단어 수를 학생별로 입력하세요. 같은 날짜는 다시 저장하면 수정됩니다.</p></div><input type="date" min={settings.start_date} max={settings.end_date} value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} /></div>
          <div className="wb-team-columns">
            {teams.map((team) => <div className="wb-score-team" key={team.id}><h3 style={{ color: team.color }}>{team.name}</h3>{members.filter((m) => m.team_id === team.id).map((member) => <label className="wb-score-row" key={member.id}><span><b>{member.name}</b><small>누적 {(totals.memberTotals[member.id] || 0).toLocaleString()}</small></span><input type="number" min="0" inputMode="numeric" placeholder="0" value={counts[member.id] ?? ""} onChange={(e) => setCounts((prev) => ({ ...prev, [member.id]: e.target.value }))} /></label>)}{!members.some((m) => m.team_id === team.id) && <p className="wb-muted">등록된 학생이 없습니다.</p>}</div>)}
          </div>
          <div className="wb-save-row"><button disabled={busy || !members.length} onClick={saveDailyScores}>{busy ? "저장 중..." : `${dayjs(selectedDate).format("M월 D일")} 기록 저장`}</button></div>
        </section>
      </>}

      {activeTab === "members" && <section className="wb-team-columns">
        {teams.map((team) => <article className="wb-card wb-team-card" key={team.id}>
          <div className="wb-team-editor"><input value={team.name} onChange={(e) => setTeams((prev) => prev.map((item) => item.id === team.id ? { ...item, name: e.target.value } : item))} /><input type="color" value={team.color} onChange={(e) => setTeams((prev) => prev.map((item) => item.id === team.id ? { ...item, color: e.target.value } : item))} /><button className="wb-small" onClick={() => saveTeam(team)}>저장</button></div>
          <div className="wb-add-member"><select value={studentChoices[team.id] || ""} onChange={(e) => setStudentChoices((prev) => ({ ...prev, [team.id]: e.target.value }))}><option value="">기존 학생에서 선택</option>{students.filter((student) => !members.some((m) => m.student_id === student.id)).map((student) => <option value={student.id} key={student.id}>{student.name} · {student.school || "학교 미등록"} {student.grade || ""}</option>)}</select><span>또는</span><input placeholder="학생 이름 직접 입력" value={newNames[team.id] || ""} onChange={(e) => setNewNames((prev) => ({ ...prev, [team.id]: e.target.value }))} /><button onClick={() => addMember(team.id)}>학생 추가</button></div>
          <div className="wb-member-list">{members.filter((m) => m.team_id === team.id).map((member) => <div className="wb-member" key={member.id}><span><b>{member.name}</b><small>{(totals.memberTotals[member.id] || 0).toLocaleString()}단어</small></span><select value={member.team_id} onChange={(e) => moveMember(member, e.target.value)}>{teams.map((target) => <option key={target.id} value={target.id}>{target.name}</option>)}</select><button className="wb-danger" onClick={() => removeMember(member)}>삭제</button></div>)}</div>
        </article>)}
      </section>}

      {activeTab === "slides" && <section className="wb-editor-grid">
        <article className="wb-card"><h2>1. 안내 화면</h2><label>큰 제목<input value={settings.event_title} onChange={(e) => setSettings({ ...settings, event_title: e.target.value })} /></label><label>부제목<input value={settings.event_subtitle} onChange={(e) => setSettings({ ...settings, event_subtitle: e.target.value })} /></label><label>본문<textarea rows="6" value={settings.event_body} onChange={(e) => setSettings({ ...settings, event_body: e.target.value })} /></label><label>배경색<input type="color" value={settings.intro_bg} onChange={(e) => setSettings({ ...settings, intro_bg: e.target.value })} /></label></article>
        <article className="wb-card"><h2>2. 규칙 화면</h2><label>큰 제목<input value={settings.rules_title} onChange={(e) => setSettings({ ...settings, rules_title: e.target.value })} /></label><label>규칙 내용<textarea rows="10" value={settings.rules_body} onChange={(e) => setSettings({ ...settings, rules_body: e.target.value })} /></label><label>배경색<input type="color" value={settings.rules_bg} onChange={(e) => setSettings({ ...settings, rules_bg: e.target.value })} /></label></article>
        <article className="wb-card"><h2>공통 설정</h2><label>강조색<input type="color" value={settings.accent_color} onChange={(e) => setSettings({ ...settings, accent_color: e.target.value })} /></label><div className="wb-date-pair"><label>시작일<input type="date" value={settings.start_date} onChange={(e) => setSettings({ ...settings, start_date: e.target.value })} /></label><label>종료일<input type="date" value={settings.end_date} onChange={(e) => setSettings({ ...settings, end_date: e.target.value })} /></label></div><label>화면 전환 시간(초)<input type="number" min="3" max="60" value={settings.slide_seconds} onChange={(e) => setSettings({ ...settings, slide_seconds: e.target.value })} /></label><button disabled={busy} onClick={saveSettings}>모든 화면 설정 저장</button></article>
      </section>}
    </main>
  );
}
